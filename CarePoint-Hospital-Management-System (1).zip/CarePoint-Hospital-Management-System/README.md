# CarePoint — Hospital Management System

**Student:** Shubham Tiwari  
**Course:** B.Sc. Computer Science  
**Institution:** JSPM University, Pune  
**Academic Year:** 2025–2026

CarePoint is a responsive, frontend-only Hospital Management System created as an academic and GitHub portfolio project. It provides a clean dashboard to demonstrate common hospital administration workflows using HTML, CSS, and JavaScript.

## Features

- Dashboard with patient, appointment, doctor, and pending-bill summaries
- Patient registration, search, and deletion
- Doctor directory with specialisations and consultation hours
- Appointment booking and status updates
- Sample billing, payment status tracking, and pending totals
- Medicine inventory with low-stock alerts
- Responsive layout for desktop and mobile
- Browser `localStorage` persistence
- Preloaded fictional sample data to make the demo easy to explore

## Technologies

- HTML5
- CSS3 (responsive layout)
- Vanilla JavaScript
- Browser `localStorage`

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Start exploring the dashboard. New records are saved in the current browser's local storage.

No package installation or database setup is required.

## Publish using GitHub Pages

1. Create a GitHub repository, for example `hospital-management-system`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish the site. The URL will appear in the Pages section.

## Demo notes and limitations

- This is a **frontend academic demo**, not a production hospital application.
- Data is stored only in the browser where the app is opened; it is not shared between users or devices.
- There is no backend, real login system, or server database.
- Do not enter real patient information, medical records, or other sensitive personal data.
- All preloaded patient and doctor entries are fictional sample records.
- This app is for demonstrating administrative workflows only and does not provide medical advice.

## Project author

**Shubham Tiwari** — B.Sc. Computer Science, JSPM University, Pune.

Created for learning, academic demonstration, and portfolio practice.
